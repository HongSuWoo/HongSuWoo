<template>
    <slot name="name"></slot>
    <slot name="founder"></slot>
    <slot name="img"></slot>
</template>