
<template>
    <h1>
        child slot data = <slot> </slot>
    </h1>

</template>